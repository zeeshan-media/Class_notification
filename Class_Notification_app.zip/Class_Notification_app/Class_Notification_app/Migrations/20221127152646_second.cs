﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Class_Notification_app.Migrations
{
    public partial class second : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
