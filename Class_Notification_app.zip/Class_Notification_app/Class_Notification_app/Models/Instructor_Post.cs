﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Class_Notification_app.Models
{
    public class Instructor_Post
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(100)]
        public string Title { get; set; }

        [MaxLength(5000)]
        public string Description { get; set; }

        [MaxLength(100)]
        public string Author { get; set; }

    }
}
