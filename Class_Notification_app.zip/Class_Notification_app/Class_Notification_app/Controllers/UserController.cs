﻿using Class_Notification_app.Data;
using Class_Notification_app.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Class_Notification_app.Controllers
{
    public class UserController : Controller
    {

        private readonly ApplicationContext context;

        public UserController(ApplicationContext context)
        {
            this.context = context;
        }
        //public IActionResult Index()
        //{
        //    return View();
        //}

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginClass model)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationContext db = new ApplicationContext())
                {
                    // Student_Login_Authentication
                    var user_student = context.User_Details.Where(i => i.Email.Equals(model.Email) && i.Password.Equals(model.Password)
                    && i.Is_superuser.Equals(false) && i.Is_instructor.Equals(false) && i.Is_student.Equals(true)).FirstOrDefault();
                    if (user_student != null)
                    {
                        return RedirectToAction("Student_Registration_Form");
                    }

                    // Superuser_login_Authentication
                    var user_superuser = context.User_Details.Where(i => i.Email.Equals(model.Email) && i.Password.Equals(model.Password)
                    && i.Is_superuser.Equals(true) && i.Is_instructor.Equals(false) && i.Is_student.Equals(false)).FirstOrDefault();
                    if (user_superuser != null)
                    {
                        return RedirectToAction("Instructor_Registration_Form");
                    }

                    var user_instructor = context.User_Details.Where(i => i.Email.Equals(model.Email) && i.Password.Equals(model.Password)
                    && i.Is_superuser.Equals(false) && i.Is_instructor.Equals(true) && i.Is_student.Equals(false)).FirstOrDefault();
                    if (user_instructor != null)
                    {
                        return RedirectToAction("Instructor_Post");
                    }
                }
            }

            return RedirectToAction("Login");

        }



        // Student Registration Form
        public IActionResult Student_Registration_Form(User_Details model)
        {
            if (ModelState.IsValid)
            {
                var stu = new User_Details
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    Password = model.Password,
                    Is_superuser = false,
                    Is_instructor = false,
                    Is_student = true
                };
                context.User_Details.Add(stu);
                context.SaveChanges();
                return RedirectToAction("Login");
            }
            else
            {
                TempData["error"] = "Empty Filed cannot Submit";
                return View(model);
            }
        }

        // Instructor Registration Form
        public IActionResult Instructor_Registration_Form(User_Details model)
        {
            if (ModelState.IsValid)
            {
                var stu = new User_Details
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    Password = model.Password,
                    Is_superuser = false,
                    Is_instructor = true,
                    Is_student = false
                };
                context.User_Details.Add(stu);
                context.SaveChanges();
                return RedirectToAction("Login");
            }
            else
            {
                TempData["error"] = "Empty Filed cannot Submit";
                return View(model);
            }
        }


        public IActionResult Instructor_Post()
        {
            var result = context.Instructor_Post.ToList();
            return View(result);
        }


        public IActionResult Create_Post()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public IActionResult Create_Post(Instructor_Post model)
        {
            if (ModelState.IsValid)
            {
                var post = new Instructor_Post
                {
                    Title = model.Title,
                    Description = model.Description,
                    Author = model.Author
                };
                context.Instructor_Post.Add(post);
                context.SaveChanges();
                return RedirectToAction("Instructor_Post");
            }
            else
            {
                TempData["error"] = "Empty Filed cannot Submit";
                return View(model);
            }

        }
        public IActionResult Landing_Page()
        {
            var result = context.Instructor_Post.ToList();
            return View(result);
        }


        public IActionResult Logout()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var cookiesSaved = Request.Cookies.Keys;
            foreach(var cookies in cookiesSaved)
            {
                Response.Cookies.Delete(cookies);
            }
            return RedirectToAction("Login");
        }
    }
}
