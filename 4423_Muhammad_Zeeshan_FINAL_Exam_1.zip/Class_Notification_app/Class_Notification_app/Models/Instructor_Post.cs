﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Class_Notification_app.Models
{
    public class Instructor_Post
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(100)]
        [Required(ErrorMessage ="Title is Required")]
        public string Title { get; set; }

        [MaxLength(5000)]
        [Required(ErrorMessage = "Post Description is Required")]
        public string Description { get; set; }

        [MaxLength(100)]
        [Required]
        public string Author { get; set; }

    }
}
