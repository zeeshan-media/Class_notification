﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Class_Notification_app.Models
{
    [Index(nameof(Email), IsUnique = true)]
    public class User_Details
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(100)]
        [Required(ErrorMessage ="Plz Enter first Name")]
        public string FirstName { get; set; }

        [MaxLength(100)]
        [Required(ErrorMessage = "Plz Enter Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage ="Plz Enter Email")]
        [MaxLength(100)]
        public string Email { get; set; }

        [Required(ErrorMessage ="Plz Enter Password")]
        [MaxLength(100)]
        public string Password { get; set; }

        [Required]
        public bool Is_superuser { get; set; }

        [Required]
        public bool Is_instructor { get; set; }

        [Required]
        public bool Is_student { get; set; }

    }
}
