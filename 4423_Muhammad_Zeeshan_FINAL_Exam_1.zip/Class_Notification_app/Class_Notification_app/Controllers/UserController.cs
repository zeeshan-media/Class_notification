﻿using Class_Notification_app.Data;
using Class_Notification_app.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using Microsoft.Data.SqlClient;

namespace Class_Notification_app.Controllers
{
    public class UserController : Controller
    {

        private readonly ApplicationContext context;

        public UserController(ApplicationContext context)
        {
            this.context = context;
        }

        public IActionResult Login() // This method gets us to the Login page 
        {
            if(!User.Identity.IsAuthenticated)
            { 
                return View();
            }
            return RedirectToAction("Landing_Page");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginClass model)  // After taking the data from login input fields, when we click submit 
        {                                             // Data gets into this model variable and then all the authentication is done here!
            if (ModelState.IsValid)
            {
                using (ApplicationContext db = new ApplicationContext())
                {
                    // Student_Login_Authentication
                    var user = context.User_Details.Where(i => i.Email.Equals(model.Email) && i.Password.Equals(model.Password)).FirstOrDefault();

                    if (user != null && user.Is_student == true)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, user.FirstName + " " + user.LastName) },
                            CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        HttpContext.Session.SetString("User_Type", "Student");
                        return RedirectToAction("Landing_Page");
                    }

                    // Superuser_login_Authentication
                    else if (user != null && user.Is_superuser == true)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, user.FirstName + " " + user.LastName) },
                           CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        HttpContext.Session.SetString("Author", user.FirstName + " " + user.LastName);
                        HttpContext.Session.SetString("User_Type", "SuperUser");
                        return RedirectToAction("Landing_Page");
                    }

                    // Instructor Login Authentication
                    else if (user != null && user.Is_instructor == true)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, user.FirstName + " " + user.LastName) },
                           CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        HttpContext.Session.SetString("Author", user.FirstName + " " + user.LastName);
                        HttpContext.Session.SetString("User_Type", "Instructor");
                        return RedirectToAction("Landing_Page");

                    }
                }
            }
            else
            {
                TempData["LoginError"] = "Both Email and password are Required";
                return View();
            }
            TempData["LoginError"] = "Incorrect Email/Password";
            return View();

        }

        public IActionResult Student_Registration_Form() // when a user click on the register button this funcction gets invoked
        {
            if(!User.Identity.IsAuthenticated)
            {
                return View();
            }
            return RedirectToAction("Landing_Page");
        }

        // Student Registration Form
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Student_Registration_Form(User_Details model) // when a user clicks on the submit button he is asked to submit a form, 
        {                                              // from which passes values into the model attribute.
            if (ModelState.IsValid)
            {
                var stu = new User_Details
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    Password = model.Password,
                    Is_superuser = false,
                    Is_instructor = false,
                    Is_student = true
                };
                context.User_Details.Add(stu);
                try {

                    context.SaveChanges();   
                } 
                catch
                {
                    TempData["UniqueKeyError"] = "Email is Already Registered Plz Try Again";
                        return View();
                }
                TempData["Student_Added"] = "Student is Added in the Database successfully!";
                return RedirectToAction("Login");
                
            }
            else
            {
                return View(); 
            }
        }


        public IActionResult Instructor_Registration_Form() // When Superuser is logged in he is redirected to this view;
        {
            if (User.Identity.IsAuthenticated && HttpContext.Session.GetString("User_Type") == "SuperUser")
            {
                return View();
            }
            return RedirectToAction("Login");
        }
        // Instructor Registration Form
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Instructor_Registration_Form(User_Details model) //when superuser is logged in, he is rediercted to
        {                                                 // Instructor registration form, after submission the values are passed into 
            if (ModelState.IsValid)                       // This function.
            {
                var stu = new User_Details
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    Password = model.Password,
                    Is_superuser = false,
                    Is_instructor = true,
                    Is_student = false
                };
                context.User_Details.Add(stu);
                try
                {
                    context.SaveChanges();
                }
                catch
                {
                    TempData["UniqueKeyError"] = "Email is Already Registered Plz Try Again";
                    return View();
                }
                TempData["Instructor_Added"] = "Instructor is Added in the Database successfully!";
                return View();
            }
            else
            {
                return View();
            }
        }


        public IActionResult Instructor_Post()   // To show the instrutor the added posts on his page after login.
        {
            
            if (User.Identity.IsAuthenticated && HttpContext.Session.GetString("User_Type") == "Instructor")
            {
                var result = context.Instructor_Post.ToList();
                return View(result);
            }
            return RedirectToAction("Login");
 
        }


        public IActionResult Create_Post()      // When Instructor clicks on add button he is 
        {
            if (User.Identity.IsAuthenticated && HttpContext.Session.GetString("User_Type") == "Instructor")
            {
                return View();
            }

            return RedirectToAction("Login");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create_Post(Instructor_Post model) // When Instructor clicks submit button the following code gets executed;
        {
            if (ModelState.IsValid)
            {
                var post = new Instructor_Post
                {
                    Title = model.Title,
                    Description = model.Description,
                    Author = HttpContext.Session.GetString("Author")
                    
                };
                context.Instructor_Post.Add(post);
                context.SaveChanges();
                TempData["Add_Post"] = "Post is Added to the DataBase successfully";
                return RedirectToAction("Instructor_Post");
            }
            else
            {
                return View();
            }

        }
        public IActionResult Landing_Page()  // This is to show posts on the landing page
        {
            if (User.Identity.IsAuthenticated)
            {
                var result = context.Instructor_Post.ToList();
                return View(result);
            }
            return RedirectToAction("Login");
        }


        public IActionResult Logout() // For Logout 
        {
            if (User.Identity.IsAuthenticated)
            {
                HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                var cookiesSaved = Request.Cookies.Keys; // To remove the cookies, help was taken from youtube video for this part...
                foreach (var cookies in cookiesSaved)
                {
                    Response.Cookies.Delete(cookies);
                }

            return RedirectToAction("Login");
            }
            return RedirectToAction("Login");
        }
    }
}
