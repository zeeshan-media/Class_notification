


insert into User_Details(FirstName, LastName, Email, Password, Is_superuser, Is_instructor,Is_student)
values
('Muhammad','Zeeshan','zeeshan@gmail.com','12345678',1,0,0);


select * from User_Details;
select * from Instructor_Post;

