﻿using Class_Notification_app.Data;
using Class_Notification_app.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace Class_Notification_app.Controllers
{
    public class UserController : Controller
    {

        private readonly ApplicationContext context;

        public UserController(ApplicationContext context)
        {
            this.context = context;
        }

        public IActionResult Login() // This method gets us to the Login page 
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginClass model)  // After taking the data from login input fields, when we click submit 
        {                                             // Data gets into this model variable and then all the authentication is done here!
            if (ModelState.IsValid)
            {
                using (ApplicationContext db = new ApplicationContext())
                {
                    // Student_Login_Authentication
                    var user_student = context.User_Details.Where(i => i.Email.Equals(model.Email) && i.Password.Equals(model.Password)
                    && i.Is_superuser.Equals(false) && i.Is_instructor.Equals(false) && i.Is_student.Equals(true)).FirstOrDefault();
                    
                    if (user_student != null)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, user_student.FirstName + " " + user_student.LastName) },
                            CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        return RedirectToAction("Landing_Page");
                    }

                    // Superuser_login_Authentication
                    var user_superuser = context.User_Details.Where(i => i.Email.Equals(model.Email) && i.Password.Equals(model.Password)
                    && i.Is_superuser.Equals(true) && i.Is_instructor.Equals(false) && i.Is_student.Equals(false)).FirstOrDefault();
                    if (user_superuser != null)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, user_superuser.FirstName +" "+ user_superuser.LastName) },
                           CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        return RedirectToAction("Instructor_Registration_Form");
                    }

                    var user_instructor = context.User_Details.Where(i => i.Email.Equals(model.Email) && i.Password.Equals(model.Password)
                    && i.Is_superuser.Equals(false) && i.Is_instructor.Equals(true) && i.Is_student.Equals(false)).FirstOrDefault();
                    if (user_instructor != null)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, user_instructor.FirstName + " " + user_instructor.LastName) },
                           CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        return RedirectToAction("Instructor_Post");
                        HttpContext.Session.SetString("Author", user_instructor.FirstName + " " + user_instructor.LastName);
                    }
                }
            }
            else { TempData["LoginError"] = "Incorrect Email or Password"; }
            return RedirectToAction("Login");

        }



        // Student Registration Form
        public IActionResult Student_Registration_Form(User_Details model) // when a user clicks on the register button he is asked to submit a form, 
        {                                              // from which passes values into the model attribute.
            if (ModelState.IsValid)
            {
                var stu = new User_Details
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    Password = model.Password,
                    Is_superuser = false,
                    Is_instructor = false,
                    Is_student = true
                };
                context.User_Details.Add(stu);
                context.SaveChanges();
                return RedirectToAction("Login");
            }
            else
            {
                TempData["error"] = "Empty Filed cannot Submit";
                return View(model);
            }
        }

        // Instructor Registration Form
        public IActionResult Instructor_Registration_Form(User_Details model) //when superuser is logged in, he is rediercted to
        {                                                 // Instructor registration form, after submission the values are passed into 
            if (ModelState.IsValid)                       // This function.
            {
                var stu = new User_Details
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    Password = model.Password,
                    Is_superuser = false,
                    Is_instructor = true,
                    Is_student = false
                };
                context.User_Details.Add(stu);
                context.SaveChanges();
                return RedirectToAction("Login");
            }
            else
            {
                TempData["error"] = "Incorrect Email or Password";
                return View(model);
            }
        }


        public IActionResult Instructor_Post()   // To show the instrutor the added posts on his page after login.
        {
            var result = context.Instructor_Post.ToList();
            return View(result);
        }


        public IActionResult Create_Post()      // When Instructor clicks on add button he is 
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public IActionResult Create_Post(Instructor_Post model)
        {
            if (ModelState.IsValid)
            {
                var post = new Instructor_Post
                {
                    Title = model.Title,
                    Description = model.Description,
                    Author = HttpContext.Session.GetString("Author")
                };
                context.Instructor_Post.Add(post);
                context.SaveChanges();
                return RedirectToAction("Instructor_Post");
            }
            else
            {
                TempData["error"] = "Empty Filed cannot Submit";
                return View(model);
            }

        }
        public IActionResult Landing_Page()
        {
            var result = context.Instructor_Post.ToList();
            return View(result);
        }


        public IActionResult Logout()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var cookiesSaved = Request.Cookies.Keys;
            foreach(var cookies in cookiesSaved)
            {
                Response.Cookies.Delete(cookies);
            }
            return RedirectToAction("Login");
        }
    }
}
