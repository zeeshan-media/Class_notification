﻿using Class_Notification_app.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Class_Notification_app.Data
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext()
        {
        }

        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options) { }

        public DbSet<User_Details> User_Details { get; set; }
        public DbSet<Instructor_Post> Instructor_Post { get; set; }


        // This piece of code ensures that the we use unique constraint on the email
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<User_Details>()
                .HasIndex(u => u.Email)
                .IsUnique();
        }
    }
}
